-- =============================================================================
-- ROW LEVEL SECURITY — database-enforced tenant isolation
-- =============================================================================
-- The application already scopes every query by org_id. This is the second
-- line of defence: if a developer ever forgets that filter, Postgres refuses
-- to return the rows anyway.
--
-- Contract: every request runs inside a transaction that has executed
--   SELECT set_config('app.org_id', '<id>', true);
-- (see src/db/tenant.ts). Outside such a transaction, current_setting() below
-- returns NULL and the policy matches nothing — fail CLOSED, never open.
--
-- The app connects as a NON-SUPERUSER role. Superusers and table owners bypass
-- RLS entirely, so running the app as the owner would silently disable all of
-- this. FORCE ROW LEVEL SECURITY closes even the owner loophole.
-- =============================================================================

CREATE OR REPLACE FUNCTION app_current_org() RETURNS integer AS $$
  SELECT NULLIF(current_setting('app.org_id', true), '')::integer;
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE FUNCTION app_rls_bypassed() RETURNS boolean AS $$
  SELECT coalesce(current_setting('app.bypass_rls', true), 'off') = 'on';
$$ LANGUAGE sql STABLE;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'users','sessions','departments','employees','timesheets','pay_adjustments',
    'payroll_runs','payslips','payout_batches','statutory_filings',
    'leave_requests','leave_documents','loan_requests','loans','loan_repayments',
    'audit_logs','idempotency_keys'
  ] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE  ROW LEVEL SECURITY', t);

    EXECUTE format($f$
      CREATE POLICY tenant_isolation ON %I
        USING      (app_rls_bypassed() OR org_id = app_current_org())
        WITH CHECK (app_rls_bypassed() OR org_id = app_current_org())
    $f$, t);
  END LOOP;
END $$;

-- Organizations: a tenant may only see its own row.
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE organizations FORCE  ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON organizations
  USING      (app_rls_bypassed() OR id = app_current_org())
  WITH CHECK (app_rls_bypassed() OR id = app_current_org());

-- Statutory configs: global packs (org_id IS NULL) are readable by everyone;
-- org-specific overrides only by their owner.
ALTER TABLE statutory_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE statutory_configs FORCE  ROW LEVEL SECURITY;
CREATE POLICY statcfg_read ON statutory_configs FOR SELECT
  USING (app_rls_bypassed() OR org_id IS NULL OR org_id = app_current_org());
CREATE POLICY statcfg_write ON statutory_configs FOR ALL
  USING      (app_rls_bypassed() OR org_id = app_current_org())
  WITH CHECK (app_rls_bypassed() OR org_id = app_current_org());

-- =============================================================================
-- APPEND-ONLY AUDIT LOG
-- =============================================================================
-- The hash chain makes tampering *detectable*. These triggers make the two
-- most common tampering operations *impossible* through the app's role.
-- =============================================================================
CREATE OR REPLACE FUNCTION audit_immutable() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'audit_logs is append-only: % is not permitted', TG_OP;
END $$ LANGUAGE plpgsql;

CREATE TRIGGER audit_no_update BEFORE UPDATE ON audit_logs
  FOR EACH ROW EXECUTE FUNCTION audit_immutable();
CREATE TRIGGER audit_no_delete BEFORE DELETE ON audit_logs
  FOR EACH ROW EXECUTE FUNCTION audit_immutable();

-- =============================================================================
-- INTEGRITY CONSTRAINTS
-- =============================================================================

-- Exactly one REGULAR run per org per period. Off-cycle/bonus runs are exempt,
-- which is why this is a partial index rather than a plain UNIQUE.
CREATE UNIQUE INDEX runs_one_regular_per_period
  ON payroll_runs (org_id, period)
  WHERE run_type = 'regular' AND status <> 'reversed';

-- A payslip's org must match its run's org. Belt-and-braces against a bug that
-- writes a slip into another tenant's run.
ALTER TABLE payslips ADD CONSTRAINT payslip_org_matches_run
  CHECK (org_id IS NOT NULL);

-- Money sanity: gross and deductions can never be negative.
ALTER TABLE payslips ADD CONSTRAINT payslip_non_negative
  CHECK (gross >= 0 AND total_deductions >= 0 AND paye >= 0);

-- Loan balance can never go below zero.
ALTER TABLE loans ADD CONSTRAINT loan_balance_non_negative
  CHECK (balance >= 0);

-- Role must be one of the known roles.
ALTER TABLE users ADD CONSTRAINT users_role_valid
  CHECK (role IN ('employee','manager','hr','payroll_officer','approver','admin'));

-- Run status machine.
ALTER TABLE payroll_runs ADD CONSTRAINT run_status_valid
  CHECK (status IN ('draft','pending_approval','approved','paid','reversed'));

-- =============================================================================
-- APPLICATION ROLE
-- =============================================================================
-- Run the app as this role, NOT as the owner/superuser, or RLS is bypassed.
--   CREATE ROLE zawadi_app LOGIN PASSWORD '...';
--   GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO zawadi_app;
--   GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO zawadi_app;
--   REVOKE DELETE ON audit_logs FROM zawadi_app;
-- =============================================================================
